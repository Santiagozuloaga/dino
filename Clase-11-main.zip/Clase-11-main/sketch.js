var trex;

function setup(){
createCanvas(600,200);
trex = createSprite(50,150,50,70);
}


function draw(){
background("black");

drawSprites();
}